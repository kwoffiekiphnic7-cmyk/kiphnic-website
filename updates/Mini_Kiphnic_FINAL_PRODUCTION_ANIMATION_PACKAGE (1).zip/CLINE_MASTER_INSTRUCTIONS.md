# CLINE MASTER INSTRUCTIONS — MINI KIPHNIC

## Mission

Integrate the Mini Kiphnic / Mini Joseph engine into the existing Kiphnic website without unnecessarily rebuilding or breaking the existing site.

The Mini Joseph system is a small autonomous website companion. He roams, notices visitors, interacts with page objects, performs page-specific activities, reacts, remembers recent behavior, and returns to roaming.

## Non-negotiable architecture

Keep these responsibilities separate:

- Brain: decides what should happen.
- Personality: mood, energy, curiosity, playfulness.
- Memory: session/persistent lightweight behavioral memory.
- Awareness: visitor/cursor/hover/click/scroll signals.
- Movement: coordinates, targets, direction, boundaries.
- Activities: code/game/phone/read/etc.
- World: discovers interactive page objects.
- Scenes: page-specific behavioral scripts.
- Renderer: only displays the current animation and position.
- Performance: visibility, reduced motion, mobile/lite behavior.

Do not turn the system into one giant JavaScript file.

## Integration procedure

1. Inspect the existing Kiphnic project.
2. Detect its framework, routing, bundler, CSS strategy, and entry points.
3. Preserve existing functionality and styling.
4. Add the Mini Kiphnic source modules in a structure compatible with the project.
5. Adapt imports/asset paths to the existing build system.
6. Add the character root as a fixed, pointer-events-none overlay.
7. Add `data-mini-page` to page roots/body where reliable.
8. Mark meaningful website objects with:
   - `data-mini-interactive`
   - `data-mini-action`
   - optional `data-mini-priority`
   - optional `data-mini-zone`
9. Connect page scenes.
10. Add placeholder/fallback assets if final artwork is not available.
11. Verify the engine works before adding production artwork.
12. Test desktop, tablet and mobile.
13. Test `prefers-reduced-motion`.
14. Test hidden-tab behavior.
15. Check for memory leaks and excessive event listeners.
16. Build the site and fix all integration errors.
17. Do not remove or replace existing site functionality merely to install Mini Joseph.

## Page behaviors

Home:
- enter
- look around
- wave
- roam
- occasional exploration

About:
- read
- think
- wave
- look around

Projects:
- notice project
- approach
- explore
- sit
- code
- think
- thumbs-up
- return to roaming

Games:
- run toward game
- sit
- play
- laugh
- celebrate
- continue playing or roam

AI:
- think
- inspect/explore
- code
- occasional surprised reaction

Services:
- explore
- code
- think
- roam

Products:
- inspect
- carry
- surprised
- wave

Contact:
- phone
- type
- look at visitor
- wave

Settings:
- inspect
- think
- sit

404:
- walk
- stop
- look left/right
- confused/surprised
- map/explore behavior if artwork exists
- shrug/wave
- walk away

## Visitor awareness

Do not react to every mouse event.

Summarize events and react occasionally.

Examples:
- mouse movement can influence facing direction
- hover on an interactive object can cause a glance
- meaningful click can cause a reaction
- long visitor inactivity can trigger autonomous behavior
- scroll can cause repositioning only when useful

Avoid intrusive behavior.

## Movement requirements

Movement must be smooth.

Never teleport unless explicitly configured.

Movement needs:
- interpolation
- direction changes
- stopping
- boundaries
- target approach distance
- responsive viewport handling

Use the renderer's horizontal flip instead of requiring duplicate left/right artwork.

## Performance requirements

- Lazy-load uncommon animations.
- Cache loaded frames.
- Avoid unnecessary DOM writes.
- Pause or greatly reduce work when `document.visibilityState === "hidden"`.
- Respect `prefers-reduced-motion`.
- Reduce autonomous events on mobile.
- Do not block page interaction.
- Do not create huge uncompressed assets.
- Avoid continuous expensive calculations.

## Accessibility

Mini Joseph must be decorative from an accessibility perspective.

The overlay must use:
`pointer-events: none`

Do not trap keyboard focus.

Do not make the animation necessary to understand or operate the website.

Reduced-motion users should receive a calm/static or minimally animated presentation.

## Asset specification

Target:
- transparent background
- 512×512 source frames
- PNG initially
- consistent character scale and anchor
- consistent feet/baseline
- no baked background
- no visible frame-to-frame jumps

Production animations:

Core:
- idle
- walk
- run
- sit
- stand

Personality:
- look-around
- wave
- point
- thumbs-up
- think
- celebrate
- laugh
- surprised
- sleep
- stretch

Website actions:
- code
- game
- phone
- read
- explore
- carry

## Fallback requirement

If final artwork is missing, do not break the website.

Use a clearly marked development placeholder or static fallback and keep the engine operational.

## Acceptance criteria

The implementation is successful when:

1. The existing Kiphnic site still works.
2. Mini Joseph appears without blocking interaction.
3. The current page selects the correct scene.
4. Mini Joseph can move to marked objects.
5. Activities can be triggered through the public API.
6. Visitor awareness works without excessive reactions.
7. Autonomous behavior works without repetitive loops.
8. Recent actions prevent immediate repetition.
9. Hidden tabs pause/reduce work.
10. Reduced motion is respected.
11. Mobile behavior is lighter.
12. Animation assets can be swapped without rewriting the engine.
13. The site builds cleanly.
14. There are no uncaught runtime errors caused by Mini Kiphnic.
15. Cline reports exactly which files were created/modified.

## Public API to preserve

```js
window.miniKiphnic.do("wave");
window.miniKiphnic.do("code");
window.miniKiphnic.walkTo("#projects");
window.miniKiphnic.runTo("#games");
window.miniKiphnic.interactWith("#project-card");
window.miniKiphnic.scene("projects");

window.miniKiphnic.sequence([
  "look-around",
  { action: "walk", target: "#projects" },
  "sit",
  { action: "code", duration: 5000 },
  "think",
  "thumbs-up",
  "stand"
]);
```

## Important

Do not invent a new version architecture.

This is the master implementation layer. Improve the implementation where necessary to fit the actual Kiphnic website, but preserve the behavioral goals and module boundaries above.
