# CLINE — BUILD MINI KIPHNIC NOW

You are implementing Mini Kiphnic / Mini Joseph inside the EXISTING Kiphnic website.

DO NOT create another architecture proposal.
DO NOT create another version/specification.
DO NOT stop after scaffolding.
DO NOT wait for final artwork.
BUILD THE WORKING SYSTEM NOW.

## SOURCE OF TRUTH

The supplied Mini Kiphnic project history defines the architecture and behavior:
Brain decides; other systems execute. The system includes Personality, Awareness, Movement, Activities, World, Scenes, Memory, Sequence, Renderer, Performance and the final observe→understand→choose→execute→react→remember loop. Use the supplied project history as the behavioral source of truth.

## FIRST TASK: INSPECT THE REAL WEBSITE

Before editing:
1. Identify framework and package manager.
2. Identify the real application entry point.
3. Identify routing/page structure.
4. Identify existing CSS strategy.
5. Identify asset/public directory.
6. Identify build and dev commands.
7. Identify whether pages are SSR/client-side.
8. Identify existing animation libraries, if any.

Then integrate into that architecture.

Do NOT replace the existing website.

## COPY THE ENGINE

Use the Mini Kiphnic master package as the implementation source.

Core modules:
- src/mini-kiphnic.js
- src/core/state-machine.js
- src/core/brain.js
- src/core/personality.js
- src/core/memory.js
- src/awareness/visitor-awareness.js
- src/movement/movement-controller.js
- src/activities/activity-controller.js
- src/world/world.js
- src/scenes/scene-manager.js
- src/scenes/scene-config.js
- src/renderer/renderer.js
- src/renderer/animation-player.js
- src/renderer/asset-loader.js
- src/performance/performance-manager.js
- mini-kiphnic.css
- character-manifest.js

Adapt imports and paths to the site's framework.

## IMPORTANT: ARTWORK IS NOT A BLOCKER

Final Mini Joseph animation frames may not exist yet.

The website MUST still run.

Implement a fallback character renderer if production assets are missing:
- simple branded CSS/SVG placeholder
- no broken image icon
- no console errors
- same position/scale/API as the final renderer

When production transparent PNG/WebP frames arrive, they must replace the fallback without changing behavior code.

## CHARACTER

The intended Mini Joseph visual identity is:
- futuristic Kiphnic character
- black/dark base
- yellow/gold primary accent
- glowing Kiphnic K
- futuristic hoodie/jacket
- headphones/tech accessory
- cargo/street-tech clothing
- expressive face
- compact 3D/cartoon presentation

Keep character size approximately 3–8% of viewport height.
He must never obstruct important UI.

## REQUIRED STATES

IDLE
WALK
RUN
TURN
SIT
STAND
INTERACT
ACTIVITY
REACT
SLEEP

## REQUIRED ANIMATIONS

Core:
idle
walk
run
sit
stand
look-around

Personality:
wave
point
thumbs-up
think
celebrate
laugh
surprised
sleep
stretch

Website:
code
game
phone
read
explore
carry

## PAGE BEHAVIOR

Home:
walk in → look around → wave → roam.

About:
find a suitable area → sit → read/type/think → occasionally notice visitor.

AI:
inspect AI-related object → think → interact → surprised/celebrate occasionally.

Projects:
approach project → inspect → sit → code → think → react.

Services:
approach service/work area → code/build → think → roam.

Games:
approach game → sit → play → laugh/celebrate.

Products:
approach product → inspect → carry/package behavior → continue.

Contact:
phone → notice visitor → wave.

Settings:
inspect controls → think → return.

404:
look around → confused/surprised → search → wave/leave.

## WORLD MARKUP

Recognize:
data-mini-interactive
data-mini-action
data-mini-priority
data-mini-zone

Also support the earlier world simulation attributes:
data-mini-world-type
data-mini-world-state
data-mini-world-priority
data-mini-world-cooldown

Example:

<div
  data-mini-interactive
  data-mini-action="explore"
  data-mini-world-type="workstation"
  data-mini-world-priority="2">
</div>

## PUBLIC API

Preserve:

window.miniKiphnic.do("wave")
window.miniKiphnic.do("code")
window.miniKiphnic.walkTo("#projects")
window.miniKiphnic.runTo("#games")
window.miniKiphnic.interactWith("#project-card")
window.miniKiphnic.scene("projects")

window.miniKiphnic.sequence([
  "look-around",
  { action: "walk", target: "#projects" },
  "sit",
  { action: "code", duration: 5000 },
  "think",
  "thumbs-up",
  "stand"
])

## VISITOR AWARENESS

Observe:
- mouse movement
- hover on meaningful interactive objects
- click
- scroll
- touch
- inactivity

Filter aggressively.

Do not make Mini Joseph react to every pixel of mouse movement.

Useful reactions:
- face visitor
- glance at hovered item
- approach meaningful object occasionally
- react after meaningful click
- autonomous activity after inactivity

## BRAIN LOOP

Implement:

observe
→ understand current page
→ inspect visitor activity
→ inspect mood/energy
→ inspect memory
→ inspect world
→ select non-repetitive action
→ execute
→ react
→ remember
→ idle
→ observe again

Brain decides.
Execution systems execute.
Renderer only renders.

## ANTI-REPETITION

Do not repeat the same autonomous action immediately.

Maintain recent action history.

Weight actions using:
- current page
- mood
- energy
- curiosity
- playfulness
- recent actions
- visitor state
- object priority

## MOVEMENT

Never teleport for normal movement.

Use:
- interpolation
- target approach point
- direction flip
- viewport boundaries
- collision/obstacle awareness where practical
- responsive viewport coordinates

On mobile:
- smaller character
- fewer autonomous events
- simpler movement
- no unnecessary running

## PERFORMANCE

Must:
- lazy-load rare animations
- cache frames
- avoid repeated layout reads
- pause when tab hidden
- respect prefers-reduced-motion
- reduce behavior on mobile
- clean up listeners/timers on destroy

No memory leaks.

## ACCESSIBILITY

The Mini overlay:
pointer-events: none

Do not trap keyboard focus.
Do not make Mini Joseph required for site operation.
Reduced motion must substantially reduce movement.

## ROUTING

For SPA sites:
- update scene when route changes
- do not reload Mini Joseph unnecessarily
- preserve the singleton where appropriate

For multi-page sites:
- initialize on each page.

## ERROR HANDLING

Missing assets must NOT break the site.

Catch image decode failures.

Fallback to placeholder renderer.

Do not flood console.

## TEST CHECKLIST

Run the site's real test/build commands.

Then manually verify:

[ ] Mini appears
[ ] No broken image
[ ] No console errors
[ ] Idle works
[ ] Walk works
[ ] Run works
[ ] Direction flips
[ ] Page scene changes
[ ] Hover reaction works
[ ] Click reaction works
[ ] Autonomous behavior works
[ ] Recent actions prevent repetition
[ ] Public API works
[ ] Mobile works
[ ] Reduced motion works
[ ] Hidden tab pauses
[ ] Existing website interaction remains unaffected
[ ] Build passes

## FINAL DELIVERABLE

When finished, report:
1. Files created
2. Files modified
3. Dependencies added
4. Integration point
5. Commands used
6. Build/test result
7. Remaining artwork files, if any
8. Exact location where final animation assets should be placed

Do not report “complete” if the real website does not build.

BUILD IT NOW.
