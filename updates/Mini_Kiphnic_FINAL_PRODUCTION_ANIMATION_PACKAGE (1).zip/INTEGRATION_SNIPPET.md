# Minimal integration

## Plain JS

```html
<link rel="stylesheet" href="/path/to/mini-kiphnic.css">

<script type="module">
  import { createMiniKiphnic } from "/path/to/src/mini-kiphnic.js";

  createMiniKiphnic({
    scale: 0.07
  });
</script>
```

## Mark objects

```html
<section
  id="projects"
  data-mini-interactive
  data-mini-action="explore"
  data-mini-priority="2">
</section>

<section
  id="games"
  data-mini-interactive
  data-mini-action="game"
  data-mini-priority="3">
</section>
```

## Set page

```html
<body data-mini-page="projects">
```
