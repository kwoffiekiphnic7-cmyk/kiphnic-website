# Mini Kiphnic Production Frame Package

This checkpoint contains extracted 512×512 transparent PNG animation frames from the approved Mini Joseph animation reference sheet.

Included sequences:
- idle, walk, run, turn, sit, stand, look-around
- wave, point, thumbs-up, think
- celebrate, laugh, surprised, sleep, stretch
- jump, dance
- code, game, phone, read, explore, carry, interact

Important:
These are the first production-ready *prototype* frames. They establish the actual file structure, frame numbering, transparency, 512×512 canvas, and renderer integration. Final art-direction passes can replace individual sequences without changing the engine.
