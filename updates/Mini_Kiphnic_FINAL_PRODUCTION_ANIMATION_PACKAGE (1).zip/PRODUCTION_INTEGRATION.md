# Production Animation Integration

The animation checkpoint is now ready for browser testing.

## Preview

Open:

`preview/index.html`

through a local HTTP server (ES modules are used, so do not rely on `file://`).

Example:

```bash
python3 -m http.server 8080
```

Then visit:

`http://localhost:8080/preview/`

## Validate

From the package root:

```bash
python3 validate_animation_assets.py
```

The validator checks:
- expected frame count
- PNG presence
- RGBA transparency channel
- 512×512 dimensions

## Cline integration

Copy the `character/` and `animations/` directories into the site's public/static asset directory and adapt the paths in `character-manifest.js` if the framework requires it.

Do not rewrite the behavior engine merely because the asset path changes.

## Production replacement

A future art pass can replace any animation directory with better frames while preserving:
- animation name
- numbered frames
- transparent PNG/WebP format
- 512×512 target canvas
- manifest entry

That allows visual refinement without changing the Brain, Movement, World, Scene or Activity systems.
