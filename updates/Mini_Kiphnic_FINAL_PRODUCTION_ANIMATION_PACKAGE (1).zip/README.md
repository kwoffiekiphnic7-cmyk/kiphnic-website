# Mini Kiphnic Master Build

Mini Joseph is a reusable website companion. The engine separates decision-making from rendering and exposes a small public API.

## Architecture

Brain → Personality / Memory / Awareness → Decision
→ Movement / Activities / World / Scenes → Renderer

## Public API

```js
window.miniKiphnic.do("wave");
window.miniKiphnic.do("code");
window.miniKiphnic.walkTo("#projects");
window.miniKiphnic.runTo("#games");
window.miniKiphnic.interactWith("#project-card");
window.miniKiphnic.scene("projects");
window.miniKiphnic.sequence([
  "look-around",
  { action: "walk", target: "#projects" },
  "sit",
  { action: "code", duration: 5000 },
  "think",
  "thumbs-up"
]);
```

## Mark interactive website objects

```html
<div
  class="project-card"
  data-mini-interactive
  data-mini-action="explore"
  data-mini-priority="2">
</div>
```

Supported action names include:
`code`, `game`, `phone`, `read`, `explore`, `carry`, `think`, `wave`,
`sleep`, `celebrate`, `laugh`, `surprised`, `stretch`, `thumbs-up`.

## Page detection

Preferred:
```html
<body data-mini-page="projects">
```

Supported scene names:
home, about, projects, games, ai, services, products, contact, settings, 404.

## Assets

The master build expects transparent PNG frame sequences. Final artwork can replace the placeholder directories without changing the engine.

The manifest controls frame counts, FPS, paths, looping, and format.
