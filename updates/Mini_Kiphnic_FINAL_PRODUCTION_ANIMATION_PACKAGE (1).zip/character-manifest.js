export default {
  "character": {
    "width": 512,
    "height": 512,
    "format": "png"
  },
  "animations": {
    "idle": {
      "path": "character/idle/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "walk": {
      "path": "character/walk/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "run": {
      "path": "character/run/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "turn": {
      "path": "animations/turn/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "sit": {
      "path": "character/sit/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "stand": {
      "path": "character/stand/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "look-around": {
      "path": "animations/look-around/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "wave": {
      "path": "animations/wave/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "point": {
      "path": "animations/point/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "thumbs-up": {
      "path": "animations/thumbs-up/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "think": {
      "path": "animations/think/",
      "frames": 6,
      "fps": 12,
      "loop": true
    },
    "celebrate": {
      "path": "animations/celebrate/",
      "frames": 8,
      "fps": 12,
      "loop": false
    },
    "laugh": {
      "path": "animations/laugh/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "surprised": {
      "path": "animations/surprised/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "sleep": {
      "path": "animations/sleep/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "stretch": {
      "path": "animations/stretch/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "jump": {
      "path": "animations/jump/",
      "frames": 6,
      "fps": 12,
      "loop": false
    },
    "dance": {
      "path": "animations/dance/",
      "frames": 8,
      "fps": 12,
      "loop": false
    },
    "code": {
      "path": "animations/code/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "game": {
      "path": "animations/game/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "phone": {
      "path": "animations/phone/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "read": {
      "path": "animations/read/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "explore": {
      "path": "animations/explore/",
      "frames": 6,
      "fps": 12,
      "loop": true
    },
    "carry": {
      "path": "animations/carry/",
      "frames": 8,
      "fps": 12,
      "loop": true
    },
    "interact": {
      "path": "animations/interact/",
      "frames": 8,
      "fps": 12,
      "loop": false
    }
  }
};
