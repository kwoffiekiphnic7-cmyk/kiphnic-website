export class ActivityController {
  constructor(engine) {
    this.engine = engine;
    this.running = false;
  }

  async play(name, options = {}) {
    if (this.running && !options.interrupt) return false;
    this.running = true;
    this.engine.stateMachine.transition("ACTIVITY", { activity: name });
    this.engine.memory.rememberAction(name);

    const duration = options.duration ?? ({
      code: 5000, game: 6000, phone: 3500, read: 4500,
      think: 2200, wave: 1500, explore: 2200, sleep: 5000,
      celebrate: 1800, laugh: 1800, "look-around": 1800,
      stretch: 2500, "thumbs-up": 1400
    }[name] || 2000);

    await this.engine.renderer.play(name);
    await new Promise(resolve => setTimeout(resolve, duration));

    if (["sit","code","game","read","sleep"].includes(name)) {
      this.engine.stateMachine.transition(name === "sleep" ? "SLEEP" : "REACT");
    } else {
      this.engine.stateMachine.transition("IDLE");
    }

    this.running = false;
    return true;
  }
}
