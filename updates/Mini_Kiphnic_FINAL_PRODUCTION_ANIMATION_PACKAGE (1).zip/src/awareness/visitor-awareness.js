export class VisitorAwareness {
  constructor() {
    this.mouse = { x: 0, y: 0, moving: false };
    this.hover = null;
    this.lastActivity = performance.now();
    this.scrollY = window.scrollY;
    this.listeners = new Map();
    this.bound = [];
    this.init();
  }

  init() {
    const onMouse = e => {
      this.mouse = { x: e.clientX, y: e.clientY, moving: true };
      this.lastActivity = performance.now();
      this.emit("mousemove", e);
    };
    const onScroll = e => {
      this.scrollY = window.scrollY;
      this.lastActivity = performance.now();
      this.emit("scroll", e);
    };
    const onClick = e => {
      this.lastActivity = performance.now();
      this.emit("click", e);
    };
    const onMoveEnd = () => { this.mouse.moving = false; };

    window.addEventListener("mousemove", onMouse, { passive: true });
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("click", onClick, { passive: true });
    window.addEventListener("mouseleave", onMoveEnd, { passive: true });

    this.bound.push(
      ["mousemove", onMouse], ["scroll", onScroll],
      ["click", onClick], ["mouseleave", onMoveEnd]
    );

    document.addEventListener("mouseover", e => {
      const target = e.target.closest?.("[data-mini-interactive]");
      if (target) {
        this.hover = target;
        this.emit("hover", target);
      }
    }, { passive: true });
  }

  on(event, listener) {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event).add(listener);
    return () => this.listeners.get(event)?.delete(listener);
  }

  emit(event, payload) {
    for (const listener of this.listeners.get(event) || []) listener(payload);
  }

  get idleFor() {
    return performance.now() - this.lastActivity;
  }

  destroy() {
    for (const [event, fn] of this.bound) window.removeEventListener(event, fn);
  }
}
