export class Brain {
  constructor(engine) {
    this.engine = engine;
    this.timer = null;
    this.lastDecision = 0;
  }

  start() {
    this.timer = setInterval(() => this.update(), 4500);
  }

  async update() {
    if (this.engine.paused || this.engine.activity.running || this.engine.movement.isMoving()) return;

    this.engine.personality.tick(4.5);
    const awareness = this.engine.awareness;

    if (awareness.idleFor > 30000 && this.engine.performance.shouldAutonomouslyAct()) {
      const action = this.engine.personality.getRandomEvent(this.engine.memory);
      return this.engine.do(action);
    }

    const current = this.engine.scenes.getCurrent();
    const scene = this.engine.sceneConfig[current];
    if (scene?.randomActions?.length && Math.random() < 0.35) {
      const action = this.engine.personality.chooseRandom(scene.randomActions, this.engine.memory);
      this.engine.do(action);
    }
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
  }
}
