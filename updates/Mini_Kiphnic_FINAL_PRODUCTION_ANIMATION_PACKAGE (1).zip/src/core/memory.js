export class Memory {
  constructor(key = "mini-kiphnic-memory") {
    this.key = key;
    this.data = {
      visitCount: 0,
      lastPage: null,
      lastActivity: null,
      lastObject: null,
      interactions: 0,
      recentActions: []
    };
    this.load();
  }

  load() {
    try {
      const saved = JSON.parse(localStorage.getItem(this.key) || "null");
      if (saved) this.data = { ...this.data, ...saved };
    } catch {}
    this.data.visitCount += 1;
    this.save();
  }

  save() {
    try { localStorage.setItem(this.key, JSON.stringify(this.data)); } catch {}
  }

  rememberAction(action) {
    this.data.lastActivity = action;
    this.data.recentActions = [...this.data.recentActions.filter(a => a !== action), action].slice(-6);
    this.save();
  }

  rememberObject(object) {
    this.data.lastObject = object;
    this.data.interactions += 1;
    this.save();
  }

  setPage(page) {
    this.data.lastPage = page;
    this.save();
  }

  hasRecentlyDone(action) {
    return this.data.recentActions.includes(action);
  }
}
