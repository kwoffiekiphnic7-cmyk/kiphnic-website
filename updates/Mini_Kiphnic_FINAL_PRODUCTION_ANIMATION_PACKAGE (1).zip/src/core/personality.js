export class Personality {
  constructor() {
    this.mood = "NORMAL";
    this.energy = 70;
    this.curiosity = 70;
    this.playfulness = 65;
  }

  setMood(mood) { this.mood = mood; }

  tick(deltaSeconds = 1) {
    this.energy = Math.max(0, Math.min(100, this.energy - deltaSeconds * 0.08));
  }

  recharge(amount = 12) {
    this.energy = Math.min(100, this.energy + amount);
  }

  chooseRandom(candidates, memory) {
    const fresh = candidates.filter(a => !memory.hasRecentlyDone(a));
    const pool = fresh.length ? fresh : candidates;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  getRandomEvent(memory) {
    if (this.energy < 30) {
      return this.chooseRandom(["sit","stretch","sleep","think"], memory);
    }
    if (this.energy > 80) {
      return this.chooseRandom(["run","celebrate","explore","wave"], memory);
    }
    return this.chooseRandom(
      ["look-around","stretch","wave","think","explore","phone","sit"],
      memory
    );
  }
}
