export class StateMachine {
  constructor(initial = "IDLE") {
    this.state = initial;
    this.listeners = new Set();
    this.transitions = {
      IDLE: ["WALK","RUN","TURN","SIT","STAND","INTERACT","ACTIVITY","REACT","SLEEP"],
      WALK: ["IDLE","RUN","TURN","STOP","SIT","INTERACT","ACTIVITY","REACT"],
      RUN: ["IDLE","WALK","TURN","STOP","INTERACT","ACTIVITY","REACT"],
      TURN: ["IDLE","WALK","RUN","STOP"],
      STOP: ["IDLE","WALK","RUN","SIT","STAND"],
      SIT: ["STAND","ACTIVITY","REACT","SLEEP"],
      STAND: ["IDLE","WALK","RUN","INTERACT","ACTIVITY","REACT"],
      INTERACT: ["IDLE","ACTIVITY","REACT","STAND"],
      ACTIVITY: ["IDLE","SIT","STAND","REACT"],
      REACT: ["IDLE","WALK","RUN","SIT","STAND","ACTIVITY"],
      SLEEP: ["STAND","IDLE"]
    };
  }

  canTransition(next) {
    return next === this.state || (this.transitions[this.state] || []).includes(next);
  }

  transition(next, meta = {}) {
    if (!this.canTransition(next)) return false;
    const previous = this.state;
    this.state = next;
    for (const listener of this.listeners) listener({ previous, next, meta });
    return true;
  }

  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}
