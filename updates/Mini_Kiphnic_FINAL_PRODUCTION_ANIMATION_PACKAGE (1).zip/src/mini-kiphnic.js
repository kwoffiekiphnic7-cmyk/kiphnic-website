import { StateMachine } from "./core/state-machine.js";
import { Memory } from "./core/memory.js";
import { Personality } from "./core/personality.js";
import { VisitorAwareness } from "./awareness/visitor-awareness.js";
import { MovementController } from "./movement/movement-controller.js";
import { Renderer } from "./renderer/renderer.js";
import { World } from "./world/world.js";
import { ActivityController } from "./activities/activity-controller.js";
import { SceneManager } from "./scenes/scene-manager.js";
import { scenes } from "./scenes/scene-config.js";
import { PerformanceManager } from "./performance/performance-manager.js";
import { Brain } from "./core/brain.js";
import manifest from "../character-manifest.js";

export class MiniKiphnic {
  constructor(options = {}) {
    this.options = options;
    this.paused = false;
    this.stateMachine = new StateMachine();
    this.memory = new Memory(options.memoryKey);
    this.personality = new Personality();
    this.awareness = new VisitorAwareness();
    this.world = new World();
    this.sceneConfig = scenes;

    const root = options.root || this.createRoot();
    this.renderer = new Renderer({ root, manifest });
    this.movement = new MovementController(this.renderer, this.stateMachine);
    this.activity = new ActivityController(this);
    this.scenes = new SceneManager(this, scenes);
    this.performance = new PerformanceManager(this);
    this.brain = new Brain(this);

    this.awareness.on("hover", el => this.handleHover(el));
    this.stateMachine.onChange(({ next }) => {
      if (next === "WALK") this.renderer.play("walk");
      if (next === "RUN") this.renderer.play("run");
      if (next === "IDLE") this.renderer.play("idle");
    });
  }

  createRoot() {
    const root = document.createElement("div");
    root.id = "mini-kiphnic";
    document.body.appendChild(root);
    return root;
  }

  async init() {
    this.world.scan();
    this.movement.start();
    this.renderer.setScale(this.options.scale ?? 0.07);
    this.renderer.setPosition(this.options.x ?? 50, this.options.y ?? 75);
    await this.renderer.play("idle");
    this.brain.start();
    this.scene(this.detectPage());
    return this;
  }

  detectPage() {
    const declared = document.body.dataset.miniPage;
    if (declared && this.sceneConfig[declared]) return declared;
    const path = location.pathname.toLowerCase();
    for (const key of Object.keys(this.sceneConfig)) {
      if (key !== "404" && path.includes(key)) return key;
    }
    return path === "/" || path === "" ? "home" : "home";
  }

  async do(action, options = {}) {
    if (this.paused) return false;

    if (action === "walk") {
      if (options.target) return this.walkTo(options.target);
      return false;
    }
    if (action === "run") {
      if (options.target) return this.runTo(options.target);
      return false;
    }
    if (action === "stand") {
      this.stateMachine.transition("STAND");
      await this.renderer.play("stand");
      return this.renderer.play("idle");
    }
    if (action === "sit") {
      this.stateMachine.transition("SIT");
      return this.activity.play("sit", options);
    }
    return this.activity.play(action, options);
  }

  walkTo(target) {
    return this.movement.targetElement(target, { run: false });
  }

  runTo(target) {
    return this.movement.targetElement(target, { run: true });
  }

  interactWith(target) {
    const el = typeof target === "string" ? document.querySelector(target) : target;
    if (!el) return false;
    this.memory.rememberObject(el.id || el.dataset.miniAction || "object");
    this.movement.targetElement(el);
    setTimeout(() => this.do(el.dataset.miniAction || "explore"), 1000);
    return true;
  }

  async sequence(actions) {
    for (const item of actions) {
      if (this.paused) break;
      if (typeof item === "string") {
        await this.do(item);
      } else if (item?.action === "walk" || item?.action === "run") {
        const moved = item.action === "run"
          ? this.runTo(item.target) : this.walkTo(item.target);
        if (moved) {
          await this.waitForMovement();
        }
      } else if (item?.action) {
        await this.do(item.action, item);
      }
    }
  }

  waitForMovement(timeout = 15000) {
    return new Promise(resolve => {
      const started = performance.now();
      const check = () => {
        if (!this.movement.isMoving() || performance.now() - started > timeout) return resolve();
        requestAnimationFrame(check);
      };
      check();
    });
  }

  scene(name) {
    this.scenes.activate(name);
  }

  handleHover(el) {
    if (this.activity.running || this.movement.isMoving()) return;
    const action = el.dataset.miniAction;
    if (action && Math.random() < 0.18) {
      this.interactWith(el);
    }
  }

  setPaused(value) {
    this.paused = value;
    if (value) this.movement.stop();
  }

  destroy() {
    this.brain.stop();
    this.movement.destroy();
    this.awareness.destroy();
    this.renderer.destroy();
  }
}

export async function createMiniKiphnic(options = {}) {
  const mini = new MiniKiphnic(options);
  await mini.init();
  window.miniKiphnic = mini;
  return mini;
}
