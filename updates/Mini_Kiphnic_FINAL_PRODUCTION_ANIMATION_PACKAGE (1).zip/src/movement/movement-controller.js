export class MovementController {
  constructor(renderer, stateMachine) {
    this.renderer = renderer;
    this.stateMachine = stateMachine;
    this.x = 50;
    this.y = 70;
    this.target = null;
    this.speed = 0.12;
    this.running = false;
    this.raf = null;
  }

  start() {
    const loop = () => {
      this.update();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  update() {
    if (!this.target) return;
    const dx = this.target.x - this.x;
    const dy = this.target.y - this.y;
    const distance = Math.hypot(dx, dy);

    if (distance < 0.7) {
      this.x = this.target.x;
      this.y = this.target.y;
      this.target = null;
      this.stateMachine.transition("IDLE", { reason: "arrived" });
      this.renderer.setPosition(this.x, this.y);
      return;
    }

    const step = this.running ? this.speed * 1.8 : this.speed;
    this.x += (dx / distance) * step;
    this.y += (dy / distance) * step;

    this.renderer.setDirection(dx >= 0 ? "right" : "left");
    this.renderer.setPosition(this.x, this.y);
  }

  moveTo(x, y, { run = false } = {}) {
    this.running = run;
    this.target = {
      x: Math.max(3, Math.min(97, x)),
      y: Math.max(8, Math.min(92, y))
    };
    this.stateMachine.transition(run ? "RUN" : "WALK");
  }

  targetElement(selector, options = {}) {
    const el = typeof selector === "string" ? document.querySelector(selector) : selector;
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const x = ((r.left + r.width / 2) / window.innerWidth) * 100;
    const y = ((r.top + r.height + 40) / window.innerHeight) * 100;
    this.moveTo(x, y, options);
    return true;
  }

  stop() {
    this.target = null;
    this.running = false;
    this.stateMachine.transition("IDLE");
  }

  isMoving() { return Boolean(this.target); }

  destroy() {
    if (this.raf) cancelAnimationFrame(this.raf);
  }
}
