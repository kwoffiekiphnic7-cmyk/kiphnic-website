export class PerformanceManager {
  constructor(engine) {
    this.engine = engine;
    this.reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches || false;
    this.hidden = document.visibilityState === "hidden";
    document.addEventListener("visibilitychange", () => {
      this.hidden = document.visibilityState === "hidden";
      this.engine.setPaused(this.hidden);
    });
  }

  shouldAutonomouslyAct() {
    if (this.reducedMotion || this.hidden) return false;
    if (window.innerWidth < 700) return Math.random() > 0.55;
    return true;
  }
}
