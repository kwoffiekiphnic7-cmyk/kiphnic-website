export class AnimationPlayer {
  constructor(element, loader) {
    this.element = element;
    this.loader = loader;
    this.frames = [];
    this.index = 0;
    this.timer = null;
  }

  async play(name, { loop = true, fps = 12 } = {}) {
    this.stop();
    this.frames = await this.loader.loadAnimation(name);
    if (!this.frames.length) {
      this.element.dataset.animation = name;
      return;
    }
    const delay = 1000 / fps;
    const tick = () => {
      const frame = this.frames[this.index];
      if (frame?.src) this.element.src = frame.src;
      this.index += 1;
      if (this.index >= this.frames.length) {
        if (loop) this.index = 0;
        else return this.stop();
      }
      this.timer = setTimeout(tick, delay);
    };
    tick();
  }

  stop() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.index = 0;
  }
}
