export class AssetLoader {
  constructor(manifest) {
    this.manifest = manifest;
    this.cache = new Map();
  }

  async loadAnimation(name) {
    if (this.cache.has(name)) return this.cache.get(name);
    const spec = this.manifest.animations[name];
    if (!spec) return [];
    const frames = [];
    for (let i = 1; i <= spec.frames; i++) {
      const path = `${spec.path}${String(i).padStart(3, "0")}.${spec.format || "png"}`;
      const img = new Image();
      img.src = path;
      try { await img.decode(); } catch {}
      frames.push(img);
    }
    this.cache.set(name, frames);
    return frames;
  }
}
