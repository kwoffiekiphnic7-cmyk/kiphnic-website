import { AssetLoader } from "./asset-loader.js";
import { AnimationPlayer } from "./animation-player.js";

export class Renderer {
  constructor({ root, manifest }) {
    this.root = root;
    this.manifest = manifest;
    this.element = document.createElement("img");
    this.element.className = "mini-kiphnic__character";
    this.element.alt = "Mini Kiphnic";
    this.element.draggable = false;
    this.root.appendChild(this.element);

    this.loader = new AssetLoader(manifest);
    this.player = new AnimationPlayer(this.element, this.loader);
    this.direction = "right";
    this.scale = 0.07;
    this.visible = true;
  }

  async play(animation) {
    const spec = this.manifest.animations[animation] || {};
    await this.player.play(animation, {
      loop: spec.loop !== false,
      fps: spec.fps || 12
    });
    this.element.dataset.animation = animation;
  }

  setDirection(direction) {
    this.direction = direction;
    this.element.style.transform = `translate(-50%, -100%) scaleX(${direction === "left" ? -1 : 1}) scale(${this.scale})`;
  }

  setScale(scale) {
    this.scale = scale;
    this.setDirection(this.direction);
  }

  setPosition(x, y) {
    this.element.style.left = `${x}%`;
    this.element.style.top = `${y}%`;
  }

  setVisible(value) {
    this.visible = value;
    this.element.style.opacity = value ? "1" : "0";
  }

  destroy() {
    this.player.stop();
    this.element.remove();
  }
}
