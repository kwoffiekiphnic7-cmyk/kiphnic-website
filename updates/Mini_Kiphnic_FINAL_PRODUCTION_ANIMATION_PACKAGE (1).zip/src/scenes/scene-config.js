export const scenes = {
  home: {
    randomActions: ["look-around","wave","explore","stretch"],
    enter(engine) {
      engine.do("look-around");
    }
  },
  about: {
    randomActions: ["read","think","wave","look-around"],
    enter(engine) { engine.do("look-around"); }
  },
  projects: {
    randomActions: ["code","think","explore","thumbs-up"],
    enter(engine) {
      engine.sequence([
        "look-around",
        { action: "walk", target: "[data-mini-action='explore']" },
        "explore",
        "sit",
        { action: "code", duration: 5000 },
        "think",
        "thumbs-up",
        "stand"
      ]);
    }
  },
  games: {
    randomActions: ["game","laugh","celebrate","explore"],
    enter(engine) {
      engine.sequence([
        { action: "run", target: "[data-mini-action='game']" },
        "game",
        "laugh",
        "celebrate"
      ]);
    }
  },
  ai: {
    randomActions: ["think","explore","code","surprised"],
    enter(engine) { engine.do("think"); }
  },
  services: {
    randomActions: ["code","explore","think","wave"],
    enter(engine) { engine.do("explore"); }
  },
  products: {
    randomActions: ["explore","carry","surprised","wave"],
    enter(engine) { engine.do("explore"); }
  },
  contact: {
    randomActions: ["phone","wave","think"],
    enter(engine) {
      engine.sequence(["phone","wave"]);
    }
  },
  settings: {
    randomActions: ["think","explore","sit"],
    enter(engine) { engine.do("think"); }
  },
  "404": {
    randomActions: ["look-around","think","surprised","explore"],
    enter(engine) {
      engine.sequence(["walk","look-around","surprised","think","wave"]);
    }
  }
};
