export class SceneManager {
  constructor(engine, scenes) {
    this.engine = engine;
    this.scenes = scenes;
    this.current = null;
  }

  activate(name) {
    const scene = this.scenes[name] || this.scenes.home;
    this.current = name in this.scenes ? name : "home";
    this.engine.memory.setPage(this.current);
    if (scene?.enter) scene.enter(this.engine);
  }

  getCurrent() { return this.current; }
}
