export class World {
  constructor() {
    this.objects = [];
  }

  scan(root = document) {
    this.objects = [...root.querySelectorAll("[data-mini-interactive]")].map(el => ({
      element: el,
      action: el.dataset.miniAction || "explore",
      priority: Number(el.dataset.miniPriority || 1),
      zone: el.dataset.miniZone || "default"
    }));
    return this.objects;
  }

  findByAction(action) {
    return this.objects.filter(o => o.action === action);
  }

  nearestTo(x, y) {
    let best = null;
    let distance = Infinity;
    for (const object of this.objects) {
      const r = object.element.getBoundingClientRect();
      const ox = r.left + r.width / 2;
      const oy = r.top + r.height / 2;
      const dx = ox - x;
      const dy = oy - y;
      const d = Math.hypot(dx, dy);
      if (d < distance) { distance = d; best = object; }
    }
    return best;
  }
}
