#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import json, sys

root = Path(__file__).resolve().parent
manifest = json.loads((root/"character-manifest.json").read_text())

errors=[]
checked=0
for name,spec in manifest["animations"].items():
    folder=root/spec["path"]
    expected=spec["frames"]
    files=sorted(folder.glob("*.png"))
    if len(files)!=expected:
        errors.append(f"{name}: expected {expected} PNGs, found {len(files)}")
    for f in files:
        checked += 1
        try:
            im=Image.open(f)
            if im.mode!="RGBA":
                errors.append(f"{f}: not RGBA")
            if im.size!=(512,512):
                errors.append(f"{f}: size {im.size}, expected (512,512)")
        except Exception as e:
            errors.append(f"{f}: {e}")

print(f"Checked {checked} frames across {len(manifest['animations'])} animations.")
if errors:
    print("\\n".join("ERROR: "+e for e in errors))
    sys.exit(1)
print("PASS: animation package is structurally valid.")
